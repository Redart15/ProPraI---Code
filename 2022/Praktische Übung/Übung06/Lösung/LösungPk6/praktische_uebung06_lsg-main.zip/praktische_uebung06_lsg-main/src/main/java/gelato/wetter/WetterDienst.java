package gelato.wetter;

public interface WetterDienst {
  Wetter wetterDaten();
}
