package gelato.external;

import java.time.LocalDateTime;

public class Kalender {

  public LocalDateTime now() {
    return LocalDateTime.now();
  }

}
