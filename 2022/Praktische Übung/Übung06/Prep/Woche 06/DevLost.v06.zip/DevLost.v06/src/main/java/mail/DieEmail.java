package mail;

import gelato.Kunde;

public interface DieEmail {
    public void sendMail(Kunde kunde, Mail mail);
}
