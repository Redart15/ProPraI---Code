package wetter;

public interface DasWetter {
    public Wetter wetterDaten();
}
