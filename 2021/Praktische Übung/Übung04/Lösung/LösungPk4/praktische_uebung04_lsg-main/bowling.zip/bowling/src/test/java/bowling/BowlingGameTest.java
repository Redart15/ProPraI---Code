package bowling;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;


import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class BowlingGameTest {

  BowlingGame game = new BowlingGame();

  @Test
  @DisplayName("Wenn kein einziger Treffer erzielt wird, ist der Punktestand 0")
  void test_0() {
    rollMultipleTimes(20, 0);
    assertThat(game.score()).isEqualTo(0);
  }


  @Test
  @DisplayName("Wenn bei jedem Wurf ein Pin abgeräümt wird, ist der Punktestand 20")
  void test_1() {
    rollMultipleTimes(20, 1);
    assertThat(game.score()).isEqualTo(20);
  }

  @Test
  @DisplayName("Wenn bei dem ersten Frame ein Spare geworfen wird und in jedem weiteren Wurf eine 1, ist der Punktestand 10 + 1 + 18*1 = 29")
  void test_2() {
    game.roll(4);
    game.roll(6);
    rollMultipleTimes(18, 1);
    assertThat(game.score()).isEqualTo(29);
  }


  @Test
  @DisplayName("Wenn bei dem neunten Frame ein Spare geworfen wird und in jedem anderen Wurf eine 1, ist der Punktestand 16*1 + 10 + 1 + 2*1 = 29")
  void test_3() {
    rollMultipleTimes(16, 1);
    game.roll(8);
    game.roll(2);
    rollMultipleTimes(2, 1);
    assertThat(game.score()).isEqualTo(29);
  }

  @Test
  @DisplayName("Wenn bei dem ersten Wurf ein Strike geworfen wird und in jedem weiteren Wurf eine 1, ist der Punktestand 10 + 2*1 + 18*1 = 30")
  void test_4() {
    game.roll(10);
    rollMultipleTimes(18, 1);
    assertThat(game.score()).isEqualTo(30);
  }

  @Test
  @DisplayName("Wenn bei dem dritten Wurf ein Strike geworfen wird und allen anderen Würfen eine 1, ist der Punktestand 1+1 + 10 + 2*1 + 16*1 = 30")
  void test_4b() {
    rollMultipleTimes(2, 1);
    game.roll(10);
    rollMultipleTimes(16, 1);
    assertThat(game.score()).isEqualTo(30);
  }

  @Test
  @DisplayName("Wenn bei dem ersten Frame ein Strike geworfen wird, dann eine 0 " +
      "und in jedem weiteren Wurf eine 1, ist der Punktestand 10 + 0+1 + 17*1 = 28")
  void test_5() {
    game.roll(10);
    game.roll(0);
    rollMultipleTimes(17, 1);
    assertThat(game.score()).isEqualTo(28);
  }

  @Test
  @DisplayName("Wenn beim letzen Frame ein Spare geworfen wird, dann ist ein weiterer Wurf erlaubt")
  void test_6() {
    rollMultipleTimes(18, 0);
    game.roll(5);
    game.roll(5);
    game.roll(5);
    assertThat(game.score()).isEqualTo(15);
  }

  @Test
  @DisplayName("Wenn beim letzen Frame ein Strike geworfen wird, dann sind zwei weitere Würfe erlaubt")
  void test_7() {
    rollMultipleTimes(18, 0);
    game.roll(10);
    game.roll(10);
    game.roll(5);
    assertThat(game.score()).isEqualTo(25);
  }

  @Test
  @DisplayName("Der Zwischenstandes enthält einen Spare erst nach dem Bonuswurf")
  void test_8() {
    rollMultipleTimes(4, 1);
    game.roll(1);
    game.roll(9);
    assertThat(game.score()).isEqualTo(4);
  }

  @Test
  @DisplayName("Es können keine weiteren Würfe gemacht werden, wenn das Spiel vorbei ist")
  void test_9() {
    rollMultipleTimes(20, 1);
    assertThrows(IllegalStateException.class, () -> game.roll(3));
  }

  @Test
  @DisplayName("Das perfekte Spiel hat 300 Punkte")
  void test_perfect_game() {
    rollMultipleTimes(12, 10);
    assertThat(game.score()).isEqualTo(300);
  }



  private void rollMultipleTimes(int nrRolls, int pins) {
    for (int i = 0; i < nrRolls; i++) {
      game.roll(pins);
    }
  }

}
