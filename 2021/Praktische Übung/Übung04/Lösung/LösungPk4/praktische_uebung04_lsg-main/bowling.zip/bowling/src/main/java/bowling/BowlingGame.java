package bowling;

import java.util.ArrayList;
import java.util.List;

public class BowlingGame {

  private final List<Frame> completedFrames = new ArrayList<>();
  private Frame currentFrame = new Frame();


  public void roll(int pins) {
    while (currentFrame.completed()) {
      completedFrames.add(currentFrame);
      currentFrame = currentFrame.nextFrame();
    }
    if (completedFrames.size() == 10) throw new IllegalStateException("Game has ended");
    currentFrame.roll(pins);
  }

  public int score() {
    if (currentFrame.completed()) {
      completedFrames.add(currentFrame);
    }
    return completedFrames.stream().mapToInt(Frame::score).sum();
  }

}
