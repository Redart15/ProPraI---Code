package bowling;

import java.util.Arrays;

class Frame {

  private int[] rolls = new int[3];
  private int currentRoll = 0;

  void roll(int pins) {
    rolls[currentRoll++] = pins;
  }

  public boolean completed() {
    return currentRoll == (thirdRollRequired() ? 3 : 2);
  }

  private boolean thirdRollRequired() {
    return strike() || spare();
  }

  private boolean strike() {
    return rolls[0] == 10;
  }

  private boolean spare() {
    return rolls[0] < 10 && rolls[0] + rolls[1] == 10;
  }

  public Frame nextFrame() {
    if (completed() && strike()) {
      Frame next = new Frame();
      next.roll(rolls[1]);
      next.roll(rolls[2]);
      return next;
    }
    if (completed() && spare()) {
      Frame next = new Frame();
      next.roll(rolls[2]);
      return next;
    }
    return completed() ? new Frame() : this;
  }

  public int score() {
    return Arrays.stream(rolls).sum();
  }
}
