package de.propra.defense.units;

import de.propra.defense.ui.GamePanel;

public class BugB extends AbstractBug {
  public BugB(GamePanel game, int row, int col) {
    super(game, row, col);
  }
}
