package de.propra.defense.units;

import de.propra.defense.ui.GamePanel;

public class BugA extends AbstractBug {

  public BugA(GamePanel game, int row, int col) {
    super(game, row, col);
  }
}
